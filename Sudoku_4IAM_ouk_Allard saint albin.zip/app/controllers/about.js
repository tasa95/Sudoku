var args = arguments[0] || {};

function closeWindow(){
    $.aboutWindow.close();
}

$.aboutWindow.hideNavBar();
