/****************************************************************************************
					README
*****************************************************************************************/

L’application a été testé sous IOS pour Iphone 5.
Suite à des problèmes de compatibilités elle n’est utilisable que sur cette plateforme.


